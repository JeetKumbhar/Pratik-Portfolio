import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, ChevronRight } from 'lucide-react';
import SectionTitle from '../common/SectionTitle';
import Button from '../common/Button';
import { FEATURED, photoBg } from './homeData';
import PortfolioImage from '../portfolio/PortfolioImage';
import { getFeaturedPortfolio } from '../../services/portfolioService';

export default function FeaturedPortfolio() {
  const [photos, setPhotos] = useState(null);

  useEffect(() => {
    let active = true;
    const refresh = () => getFeaturedPortfolio()
      .then((items) => {
        if (active) setPhotos(items.filter((item) => item.isPublished && item.featured));
      })
      .catch(() => {
        if (active) setPhotos([]);
      });
    refresh();
    window.addEventListener('focus', refresh);
    return () => {
      active = false;
      window.removeEventListener('focus', refresh);
    };
  }, []);

  return (
    <section className="home-section home-section--alt">
      <div className="container featured">
        <div className="featured__intro" data-reveal>
          <SectionTitle
            className="title--script"
            eyebrow="My work"
            title="Featured Work"
            subtitle="From intimate portraits to grand celebrations, explore moments I've had the privilege to capture."
            serif split
          />
          <Button to="/portfolio" variant="outline" iconRight={<ChevronRight size={16} />}>View all portfolio</Button>
        </div>

        <ul className="featured__grid" data-stagger>
          {FEATURED.map(({ category, title, to, src, fallback }) => {
            const photo = photos?.find((item) => item.category === category && item.isPublished && item.featured);
            return (
              <li key={category}>
                <Link to={to} className="work-card" aria-label={`${title} gallery`}>
                  {photo
                    ? <PortfolioImage item={photo} className="work-card__img" width={600} />
                    : <span className="work-card__img" style={{ backgroundImage: photoBg(src, fallback) }} />}
                  <span className="work-card__caption">
                    <span>
                      <span className="work-card__title">{title}</span>
                      <span className="work-card__sub">View gallery</span>
                    </span>
                    <span className="work-card__arrow"><ArrowRight size={16} /></span>
                  </span>
                </Link>
              </li>
            );
          })}
        </ul>
      </div>
    </section>
  );
}
